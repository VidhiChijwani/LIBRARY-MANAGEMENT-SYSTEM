<?php
        include "connection.php";
?>
<?php

        if($_GET['bookid'])
        {
            $bid= $_GET['bookid'];
            $query = "DELETE from book WHERE bookid = '".$bid."'";
        
            $q=mysqli_query($con,$query);
            
            if($q)
            {
                header("Location: booklist2.php");
            }
          
        }

       
?>
        